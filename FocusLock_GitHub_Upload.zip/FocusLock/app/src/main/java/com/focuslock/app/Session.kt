package com.focuslock.app

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import java.time.LocalDate

/** All persistent state: the running session, the allowlist and study stats. */
object Session {
    private const val FILE = "focuslock"

    /** Messaging apps allowed by default. Phone + SMS + keyboard are always allowed on top of this. */
    val DEFAULT_ALLOWED = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "org.telegram.messenger.web"
    )

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- allowlist -------------------------------------------------------------------------

    fun allowed(c: Context): Set<String> =
        sp(c).getStringSet("allowed", null)?.toSet() ?: DEFAULT_ALLOWED

    fun setAllowed(c: Context, packages: Set<String>) {
        sp(c).edit().putStringSet("allowed", HashSet(packages)).apply()
    }

    // ---- running session -------------------------------------------------------------------

    private fun bootCount(c: Context): Int =
        try {
            Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)
        } catch (_: Exception) {
            -1
        }

    fun start(c: Context, goal: String, minutes: Int) {
        val now = System.currentTimeMillis()
        val dur = minutes * 60_000L
        sp(c).edit()
            .putBoolean("active", true)
            .putLong("start", now)
            .putLong("end", now + dur)
            .putLong("dur", dur)
            .putLong("endEl", SystemClock.elapsedRealtime() + dur)
            .putInt("boot", bootCount(c))
            .putString("goal", goal)
            .apply()
    }

    /** Total length of the current session in ms. */
    fun durationMs(c: Context): Long = sp(c).getLong("dur", 0L).coerceAtLeast(1L)

    /**
     * Time left. Uses the monotonic clock within one boot so changing the phone's date/time cannot
     * end a session early; after a reboot it falls back to the wall clock.
     */
    fun remainingMs(c: Context): Long {
        val s = sp(c)
        val boot = bootCount(c)
        return if (boot != -1 && boot == s.getInt("boot", -2)) {
            s.getLong("endEl", 0L) - SystemClock.elapsedRealtime()
        } else {
            s.getLong("end", 0L) - System.currentTimeMillis()
        }
    }

    /**
     * True while a session exists. A session whose timer has run out is completed (and counted)
     * right here, so stats never depend on the user opening the timer screen.
     */
    fun isActive(c: Context): Boolean {
        if (!sp(c).getBoolean("active", false)) return false
        if (remainingMs(c) <= 0L) {
            finish(c, completed = true)
            return false
        }
        return true
    }

    fun goal(c: Context): String = sp(c).getString("goal", "") ?: ""

    /** True only while the timer is still counting down. This is what drives blocking. */
    fun isRunning(c: Context): Boolean = isActive(c)

    /** Ends the session. completed=false (emergency exit) resets the streak. */
    fun finish(c: Context, completed: Boolean) {
        val s = sp(c)
        if (!s.getBoolean("active", false)) return
        val e = s.edit().putBoolean("active", false)
        if (completed) {
            val minutes = (s.getLong("dur", 0L) / 60_000L).toInt()
            val today = LocalDate.now()
            val last = s.getString("lastDay", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            val streak = s.getInt("streak", 0)
            val newStreak = when (last) {
                today -> maxOf(streak, 1)
                today.minusDays(1) -> streak + 1
                else -> 1
            }
            e.putInt("streak", newStreak)
                .putString("lastDay", today.toString())
                .putInt("sessions", s.getInt("sessions", 0) + 1)
                .putInt("totalMin", s.getInt("totalMin", 0) + minutes)
        } else {
            e.putInt("streak", 0)
        }
        e.apply()
    }

    // ---- stats -----------------------------------------------------------------------------

    fun sessions(c: Context): Int = sp(c).getInt("sessions", 0)
    fun totalMinutes(c: Context): Int = sp(c).getInt("totalMin", 0)

    /** Streak that is still alive (completed today or yesterday), otherwise 0. */
    fun streak(c: Context): Int {
        val s = sp(c)
        val last = s.getString("lastDay", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?: return 0
        val today = LocalDate.now()
        return if (last == today || last == today.minusDays(1)) s.getInt("streak", 0) else 0
    }
}
