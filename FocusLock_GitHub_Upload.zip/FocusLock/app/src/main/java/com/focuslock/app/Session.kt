package com.focuslock.app

import android.content.Context
import java.time.LocalDate

/** All persistent state: the running session, the allowlist and study stats. */
object Session {
    private const val FILE = "focuslock"

    /** Messaging apps allowed by default. Phone + SMS + keyboard are always allowed on top of this. */
    val DEFAULT_ALLOWED = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "org.telegram.messenger.web",
        "com.openai.chatgpt"
    )

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- allowlist -------------------------------------------------------------------------

    fun allowed(c: Context): Set<String> =
        sp(c).getStringSet("allowed", null)?.toSet() ?: DEFAULT_ALLOWED

    fun setAllowed(c: Context, packages: Set<String>) {
        sp(c).edit().putStringSet("allowed", HashSet(packages)).apply()
    }

    // ---- running session -------------------------------------------------------------------

    fun start(c: Context, goal: String, minutes: Int) {
        val now = System.currentTimeMillis()
        sp(c).edit()
            .putBoolean("active", true)
            .putLong("start", now)
            .putLong("end", now + minutes * 60_000L)
            .putString("goal", goal)
            .apply()
    }

    fun isActive(c: Context): Boolean = sp(c).getBoolean("active", false)
    fun startTime(c: Context): Long = sp(c).getLong("start", 0L)
    fun endTime(c: Context): Long = sp(c).getLong("end", 0L)
    fun goal(c: Context): String = sp(c).getString("goal", "") ?: ""

    /** True only while the timer is still counting down. This is what drives blocking. */
    fun isRunning(c: Context): Boolean =
        isActive(c) && System.currentTimeMillis() < endTime(c)

    /** Ends the session. completed=false (emergency exit) resets the streak. */
    fun finish(c: Context, completed: Boolean) {
        val s = sp(c)
        val e = s.edit().putBoolean("active", false)
        if (completed) {
            val minutes = ((endTime(c) - startTime(c)) / 60_000L).toInt()
            val today = LocalDate.now()
            val last = s.getString("lastDay", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            val streak = s.getInt("streak", 0)
            val newStreak = when (last) {
                today -> maxOf(streak, 1)
                today.minusDays(1) -> streak + 1
                else -> 1
            }
            e.putInt("streak", newStreak)
                .putString("lastDay", today.toString())
                .putInt("sessions", s.getInt("sessions", 0) + 1)
                .putInt("totalMin", s.getInt("totalMin", 0) + minutes)
        } else {
            e.putInt("streak", 0)
        }
        e.apply()
    }

    // ---- stats -----------------------------------------------------------------------------

    fun sessions(c: Context): Int = sp(c).getInt("sessions", 0)
    fun totalMinutes(c: Context): Int = sp(c).getInt("totalMin", 0)

    /** Streak that is still alive (completed today or yesterday), otherwise 0. */
    fun streak(c: Context): Int {
        val s = sp(c)
        val last = s.getString("lastDay", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?: return 0
        val today = LocalDate.now()
        return if (last == today || last == today.minusDays(1)) s.getInt("streak", 0) else 0
    }
}
