package com.focuslock.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Tiny helpers so the whole UI can be built in code (no layout XML to maintain). */
object Ui {
    val BG = Color.parseColor("#0F1115")
    val CARD = Color.parseColor("#1B1F27")
    val ACCENT = Color.parseColor("#7C9CFF")
    val TEXT = Color.parseColor("#F2F4F8")
    val MUTED = Color.parseColor("#8B93A5")
    val GOOD = Color.parseColor("#5BD18B")
    val BAD = Color.parseColor("#FF7A7A")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radiusPx: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx.toFloat()
        }

    fun lp(c: Context, topDp: Int = 10): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(c, topDp) }

    fun label(
        c: Context,
        text: String,
        sp: Float,
        color: Int = TEXT,
        bold: Boolean = false
    ): TextView = TextView(c).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, dp(c, 16))
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
    }

    fun button(
        c: Context,
        text: String,
        filled: Boolean = true,
        onClick: () -> Unit
    ): Button = Button(c).apply {
        this.text = text
        isAllCaps = false
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        setTextColor(if (filled) BG else TEXT)
        background = rounded(if (filled) ACCENT else CARD, dp(c, 14))
        setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12))
        setOnClickListener { onClick() }
    }
}
