package com.focuslock.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout

/**
 * Watches which app is in the foreground. While a session is running, any app that is not on
 * the allowlist is instantly covered and the user is sent back to the timer screen.
 */
class BlockerService : AccessibilityService() {

    private var overlay: View? = null
    private var cache: Set<String> = emptySet()
    private var cacheAt = 0L
    private var lastBounce = 0L
    private val handler = Handler(Looper.getMainLooper())

    /** While the cover is up: drop it as soon as the session is over, and retry the bounce once. */
    private val overlayWatch = object : Runnable {
        override fun run() {
            if (overlay == null) return
            if (!Session.isRunning(this@BlockerService)) {
                hideOverlay()
                return
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return

        if (!Session.isRunning(this)) {
            hideOverlay()
            return
        }

        // Our own windows: the timer screen means we're safe again.
        if (pkg == packageName) {
            if (e.className?.toString() == LockActivity::class.java.name) hideOverlay()
            return
        }
        // Notification shade / quick settings: allowed so you can read and reply to notifications.
        if (pkg == "com.android.systemui") return

        if (pkg in allowed()) {
            hideOverlay()
            return
        }

        // Blocked app: cover it immediately, then bring the timer to the front.
        showOverlay()
        bounce()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        handler.removeCallbacksAndMessages(null)
        hideOverlay()
        return super.onUnbind(intent)
    }

    // ---- allowlist -------------------------------------------------------------------------

    private fun allowed(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (now - cacheAt < 20_000L && cache.isNotEmpty()) return cache

        val s = HashSet<String>()
        s += Session.allowed(this)
        s += packageName
        s += "android"
        s += "com.android.systemui"
        // Calls (incoming/outgoing call screens on common phones) and emergency dialer.
        s += listOf(
            "com.android.incallui",
            "com.android.server.telecom",
            "com.android.phone",
            "com.android.dialer",
            "com.google.android.dialer",
            "com.samsung.android.incallui",
            "com.samsung.android.dialer",
            "com.miui.voip",
            "com.coloros.incallui"
        )
        // Default dialer / SMS apps on this particular phone.
        try {
            getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s += it }
        } catch (_: Exception) {
        }
        try {
            Telephony.Sms.getDefaultSmsPackage(this)?.let { s += it }
        } catch (_: Exception) {
        }
        // Keyboards, otherwise you couldn't type a WhatsApp reply.
        try {
            getSystemService(InputMethodManager::class.java)
                ?.enabledInputMethodList?.forEach { s += it.packageName }
        } catch (_: Exception) {
        }
        // System screens that allowed apps depend on: permission pop-ups, photo/file pickers.
        s += listOf(
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            "com.android.documentsui",
            "com.google.android.documentsui",
            "com.google.android.providers.media.module",
            "com.android.providers.media.module",
            "com.android.providers.media",
            "com.android.camera",
            "com.android.camera2",
            "com.google.android.GoogleCamera",
            "com.sec.android.app.camera"
        )
        // Whatever handles "dial", "sms" and "take a photo" on this phone.
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        for (i in intents) {
            try {
                packageManager.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY)
                    .forEach { s += it.activityInfo.packageName }
            } catch (_: Exception) {
            }
        }

        cache = s
        cacheAt = now
        return s
    }

    // ---- bouncing back to the timer --------------------------------------------------------

    private fun lockIntent(): Intent =
        Intent(this, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)

    private fun bounce() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBounce < 300) return
        lastBounce = now
        launchTimer()
        // Android can silently refuse a background launch. Try once more shortly after; the cover
        // (with its "Back to timer" button) stays up meanwhile.
        handler.postDelayed({
            if (overlay != null && Session.isRunning(this)) launchTimer()
        }, 400)
    }

    private fun launchTimer() {
        try {
            startActivity(lockIntent())
        } catch (_: Exception) {
        }
    }

    /**
     * Opaque cover shown the instant a blocked app appears. If Android refuses to start the timer
     * activity from the background, this stays up with a button that always works.
     */
    private fun showOverlay() {
        if (overlay != null) return
        val wm = getSystemService(WindowManager::class.java) ?: return
        val pad = Ui.dp(this, 32)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Ui.BG)
            setPadding(pad, pad, pad, pad)
            addView(Ui.label(this@BlockerService, "Focus session running", 24f, bold = true))
            addView(
                Ui.label(
                    this@BlockerService,
                    "This app is blocked until your goal is done.",
                    15f,
                    Ui.MUTED
                ), Ui.lp(this@BlockerService, 8)
            )
            addView(
                Ui.button(this@BlockerService, "Back to timer") { launchTimer() }, Ui.lp(this@BlockerService, 24)
            )
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.OPAQUE
        )
        try {
            wm.addView(box, params)
            overlay = box
            handler.removeCallbacks(overlayWatch)
            handler.postDelayed(overlayWatch, 1000)
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        handler.removeCallbacks(overlayWatch)
        try {
            getSystemService(WindowManager::class.java)?.removeView(v)
        } catch (_: Exception) {
        }
    }
}
