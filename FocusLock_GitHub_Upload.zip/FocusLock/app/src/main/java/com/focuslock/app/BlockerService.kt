package com.focuslock.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.net.Uri
import android.os.SystemClock
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout

/**
 * Watches which app is in the foreground. While a session is running, any app that is not on
 * the allowlist is instantly covered and the user is sent back to the timer screen.
 */
class BlockerService : AccessibilityService() {

    private var overlay: View? = null
    private var cache: Set<String> = emptySet()
    private var cacheAt = 0L
    private var lastBounce = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return

        if (!Session.isRunning(this)) {
            hideOverlay()
            return
        }

        // Our own windows: the timer screen means we're safe again.
        if (pkg == packageName) {
            if (e.className?.toString() == LockActivity::class.java.name) hideOverlay()
            return
        }
        // Notification shade / quick settings: allowed so you can read and reply to notifications.
        if (pkg == "com.android.systemui") return

        if (pkg in allowed()) {
            hideOverlay()
            return
        }

        // Blocked app: cover it immediately, then bring the timer to the front.
        showOverlay()
        bounce()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay()
        return super.onUnbind(intent)
    }

    // ---- allowlist -------------------------------------------------------------------------

    private fun allowed(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (now - cacheAt < 20_000L && cache.isNotEmpty()) return cache

        val s = HashSet<String>()
        s += Session.allowed(this)
        s += packageName
        s += "android"
        s += "com.android.systemui"
        // Calls (incoming/outgoing call screens on common phones) and emergency dialer.
        s += listOf(
            "com.android.incallui",
            "com.android.server.telecom",
            "com.android.phone",
            "com.android.dialer",
            "com.google.android.dialer",
            "com.samsung.android.incallui",
            "com.samsung.android.dialer",
            "com.miui.voip",
            "com.coloros.incallui"
        )
        // Default dialer / SMS apps on this particular phone.
        try {
            getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s += it }
        } catch (_: Exception) {
        }
        try {
            Telephony.Sms.getDefaultSmsPackage(this)?.let { s += it }
        } catch (_: Exception) {
        }
        // Keyboards, otherwise you couldn't type a WhatsApp reply.
        try {
            getSystemService(InputMethodManager::class.java)
                ?.enabledInputMethodList?.forEach { s += it.packageName }
        } catch (_: Exception) {
        }
        // Whatever handles "dial" and "sms" on this phone.
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))
        )
        for (i in intents) {
            try {
                packageManager.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY)
                    .forEach { s += it.activityInfo.packageName }
            } catch (_: Exception) {
            }
        }

        cache = s
        cacheAt = now
        return s
    }

    // ---- bouncing back to the timer --------------------------------------------------------

    private fun lockIntent(): Intent =
        Intent(this, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)

    private fun bounce() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBounce < 300) return
        lastBounce = now
        try {
            startActivity(lockIntent())
        } catch (_: Exception) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    /**
     * Opaque cover shown the instant a blocked app appears. If Android refuses to start the timer
     * activity from the background, this stays up with a button that always works.
     */
    private fun showOverlay() {
        if (overlay != null) return
        val wm = getSystemService(WindowManager::class.java) ?: return
        val pad = Ui.dp(this, 32)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Ui.BG)
            setPadding(pad, pad, pad, pad)
            addView(Ui.label(this@BlockerService, "Focus session running", 24f, bold = true))
            addView(
                Ui.label(
                    this@BlockerService,
                    "This app is blocked until your goal is done.",
                    15f,
                    Ui.MUTED
                ), Ui.lp(this@BlockerService, 8)
            )
            addView(
                Ui.button(this@BlockerService, "Back to timer") {
                    try {
                        startActivity(lockIntent())
                    } catch (_: Exception) {
                    }
                }, Ui.lp(this@BlockerService, 24)
            )
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.OPAQUE
        )
        try {
            wm.addView(box, params)
            overlay = box
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try {
            getSystemService(WindowManager::class.java)?.removeView(v)
        } catch (_: Exception) {
        }
    }
}
