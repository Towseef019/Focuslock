package com.focuslock.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Setup screen: pick a goal + duration, choose allowed apps, grant permissions, start. */
class MainActivity : Activity() {

    private class Row(val label: TextView, val button: Button)

    private lateinit var goalInput: EditText
    private lateinit var minutesInput: EditText
    private lateinit var statsText: TextView
    private lateinit var allowedBtn: Button
    private lateinit var startBtn: Button
    private lateinit var a11yRow: Row
    private lateinit var overlayRow: Row
    private lateinit var batteryRow: Row

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        // A session is in progress (or just finished and waiting to be saved): go to the timer.
        if (Session.isActive(this)) {
            startActivity(Intent(this, LockActivity::class.java))
            return
        }
        refresh()
    }

    private fun buildUi() {
        val pad = Ui.dp(this, 20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, Ui.dp(this@MainActivity, 40), pad, pad)
        }

        root.addView(Ui.label(this, "FocusLock", 32f, Ui.TEXT, bold = true))
        root.addView(
            Ui.label(this, "Lock your phone until your goal is done.", 15f, Ui.MUTED),
            Ui.lp(this, 4)
        )

        // Stats
        statsText = Ui.label(this, "", 15f, Ui.TEXT)
        val statsCard = Ui.card(this).apply { addView(statsText) }
        root.addView(statsCard, Ui.lp(this, 20))

        // Goal + duration
        goalInput = EditText(this).apply {
            hint = "Goal (e.g. Physics ch.5, 40 questions)"
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        root.addView(goalInput, Ui.lp(this, 20))

        minutesInput = EditText(this).apply {
            hint = "Minutes"
            setText("60")
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        root.addView(minutesInput, Ui.lp(this, 6))

        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(25, 45, 60, 90, 120).forEach { m ->
            val b = Ui.button(this, "$m", filled = false) { minutesInput.setText(m.toString()) }
            presets.addView(
                b,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { marginEnd = Ui.dp(this@MainActivity, 6) }
            )
        }
        root.addView(presets, Ui.lp(this, 6))

        // Allowed apps
        allowedBtn = Ui.button(this, "Allowed apps", filled = false) { showAllowedDialog() }
        root.addView(allowedBtn, Ui.lp(this, 18))

        // Permissions
        val setup = Ui.card(this)
        setup.addView(Ui.label(this, "One-time setup", 13f, Ui.ACCENT, bold = true))
        a11yRow = addRow(setup, "Accessibility", "Enable") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find FocusLock and turn it on", Toast.LENGTH_LONG).show()
        }
        overlayRow = addRow(setup, "Display over other apps", "Allow") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        batteryRow = addRow(setup, "Unrestricted battery", "Allow") {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        setup.addView(
            Ui.label(
                this,
                "If Accessibility is greyed out (Android 13+): Settings > Apps > FocusLock > " +
                    "three-dot menu > Allow restricted settings, then try again.",
                12f, Ui.MUTED
            ), Ui.lp(this, 10)
        )
        root.addView(setup, Ui.lp(this, 18))

        // Start
        startBtn = Ui.button(this, "Start focus session") { confirmStart() }
        root.addView(startBtn, Ui.lp(this, 22))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(root)
        })
    }

    private fun addRow(parent: LinearLayout, title: String, btn: String, action: () -> Unit): Row {
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val label = Ui.label(this, title, 15f, Ui.TEXT)
        line.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val button = Ui.button(this, btn) { action() }
        line.addView(button)
        parent.addView(line, Ui.lp(this, 10))
        return Row(label, button)
    }

    private fun setRow(r: Row, name: String, ok: Boolean) {
        r.label.text = (if (ok) "✅  " else "⬜  ") + name
        r.button.visibility = if (ok) View.GONE else View.VISIBLE
    }

    private fun refresh() {
        val hours = Session.totalMinutes(this) / 60.0
        statsText.text = String.format(
            java.util.Locale.US,
            "🔥 %d-day streak   ·   %d sessions   ·   %.1f h focused",
            Session.streak(this), Session.sessions(this), hours
        )
        allowedBtn.text = "Allowed apps (${Session.allowed(this).size} + phone & SMS)"

        val a11y = isAccessibilityOn()
        setRow(a11yRow, "Accessibility (required)", a11y)
        setRow(overlayRow, "Display over other apps", Settings.canDrawOverlays(this))
        val pm = getSystemService(PowerManager::class.java)
        setRow(batteryRow, "Unrestricted battery", pm?.isIgnoringBatteryOptimizations(packageName) == true)

        startBtn.isEnabled = a11y
        startBtn.alpha = if (a11y) 1f else 0.4f
    }

    private fun isAccessibilityOn(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.split(':').any { it.contains(packageName) && it.contains("BlockerService") }
    }

    private fun confirmStart() {
        val mins = (minutesInput.text.toString().toIntOrNull() ?: 0).coerceAtMost(600)
        if (mins < 1) {
            Toast.makeText(this, "Enter how many minutes (1 to 600)", Toast.LENGTH_SHORT).show()
            return
        }
        if (!isAccessibilityOn()) {
            Toast.makeText(this, "Turn on Accessibility first", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Lock for $mins minutes?")
            .setMessage("Only calls, SMS and your allowed apps will work until the timer ends.")
            .setPositiveButton("Start") { _, _ ->
                Session.start(this, goalInput.text.toString().trim(), mins)
                startActivity(Intent(this, LockActivity::class.java))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAllowedDialog() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val current = Session.allowed(this)
        val checked = BooleanArray(apps.size) { apps[it].first in current }

        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Allowed during focus")
            .setMultiChoiceItems(
                apps.map { it.second }.toTypedArray(), checked
            ) { _, i, v -> checked[i] = v }
            .setPositiveButton("Save") { _, _ ->
                Session.setAllowed(
                    this,
                    apps.indices.filter { checked[it] }.map { apps[it].first }.toSet()
                )
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
