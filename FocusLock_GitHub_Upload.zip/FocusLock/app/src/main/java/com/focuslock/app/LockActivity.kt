package com.focuslock.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.ActionMode
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import java.util.Locale

/** The full-screen timer. Back is disabled; leaving early needs the emergency exit. */
class LockActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var timerText: TextView
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var appsBox: LinearLayout

    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.isActive(this)) {
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
    }

    private var uiBuilt = false

    private fun buildUi() {
        uiBuilt = true
        val pad = Ui.dp(this, 24)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, Ui.dp(this@LockActivity, 56), pad, pad)
        }

        root.addView(Ui.label(this, "FOCUS SESSION", 13f, Ui.ACCENT, bold = true))

        val goal = Session.goal(this)
        if (goal.isNotEmpty()) {
            root.addView(
                Ui.label(this, goal, 20f, Ui.TEXT, bold = true).apply { gravity = Gravity.CENTER },
                Ui.lp(this, 10)
            )
        }

        timerText = Ui.label(this, "00:00:00", 64f, Ui.TEXT, bold = true).apply {
            gravity = Gravity.CENTER
        }
        root.addView(timerText, Ui.lp(this, 28))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        }
        root.addView(progress, Ui.lp(this, 18))

        statusText = Ui.label(this, "", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        root.addView(statusText, Ui.lp(this, 14))

        root.addView(
            Ui.label(this, "Allowed right now", 13f, Ui.MUTED, bold = true),
            Ui.lp(this, 32)
        )
        appsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(appsBox, Ui.lp(this, 6))

        root.addView(
            Ui.button(this, "Emergency exit", filled = false) { showEmergencyExit() },
            Ui.lp(this, 36)
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        if (!Session.isActive(this)) {
            finish()
            return
        }
        if (!uiBuilt) buildUi()
        fillApps()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun hideBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // Intentionally blocked during a session.
    }

    // ---- timer -----------------------------------------------------------------------------

    private fun update() {
        val remaining = Session.remainingMs(this)
        // isActive() also completes and records the session once the timer runs out.
        if (!Session.isActive(this)) {
            if (remaining <= 0L) {
                Toast.makeText(this, "Goal complete. Session saved. Great work!", Toast.LENGTH_LONG).show()
            }
            finish()
            return
        }
        val total = remaining / 1000
        timerText.text = String.format(
            Locale.US, "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60
        )
        val span = Session.durationMs(this)
        progress.progress = (((span - remaining) * 1000) / span).toInt().coerceIn(0, 1000)
        statusText.text = "Stay with it. Only calls, SMS and your allowed apps work."
    }

    // ---- allowed apps shortcuts ------------------------------------------------------------

    private fun fillApps() {
        appsBox.removeAllViews()

        addAppButton("Phone") { Intent(Intent.ACTION_DIAL) }
        addAppButton("Messages") {
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
        }

        val pm = packageManager
        Session.allowed(this).forEach { pkg ->
            val launch = pm.getLaunchIntentForPackage(pkg) ?: return@forEach
            val name = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) {
                pkg
            }
            addAppButton(name) { launch }
        }
    }

    private fun addAppButton(name: String, intent: () -> Intent) {
        appsBox.addView(
            Ui.button(this, name, filled = false) {
                try {
                    startActivity(intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                    Toast.makeText(this, "Can't open $name", Toast.LENGTH_SHORT).show()
                }
            }, Ui.lp(this, 8)
        )
    }

    // ---- emergency exit --------------------------------------------------------------------

    private val exitText =
        "I am quitting my study session early. I know this will break my streak and that I " +
            "promised myself I would stay focused until my goal was done. I am choosing to " +
            "stop on purpose and not just because I feel bored."

    private fun showEmergencyExit() {
        val pad = Ui.dp(this, 20)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        box.addView(Ui.label(this, "Type this paragraph exactly to quit:", 14f, Ui.TEXT))
        box.addView(Ui.label(this, exitText, 14f, Ui.ACCENT), Ui.lp(this, 10))

        // No paste: you have to actually type it.
        val noMenu = object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode?, menu: Menu?) = false
            override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?) = false
            override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?) = false
            override fun onDestroyActionMode(mode: ActionMode?) {}
        }
        val input = EditText(this).apply {
            // VISIBLE_PASSWORD makes keyboards hide suggestions and the clipboard chip.
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            minLines = 3
            gravity = Gravity.TOP
            isLongClickable = false
            customSelectionActionModeCallback = noMenu
            customInsertionActionModeCallback = noMenu
            hint = "Type here"
        }
        box.addView(input, Ui.lp(this, 10))

        val dialog = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Emergency exit")
            .setView(box)
            .setPositiveButton("Quit session") { _, _ ->
                Session.finish(this, completed = false)
                finish()
            }
            .setNegativeButton("Keep going", null)
            .create()
        dialog.show()

        val quit = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
        quit.isEnabled = false
        var previous = ""
        var reverting = false
        input.doAfterTextChanged {
            if (reverting) return@doAfterTextChanged
            val now = it?.toString() ?: ""
            // A big jump in one go means it was pasted (e.g. from the keyboard's clipboard chip).
            if (now.length - previous.length > 12) {
                reverting = true
                input.setText(previous)
                input.setSelection(previous.length)
                reverting = false
                Toast.makeText(this, "Pasting is not allowed. Type it.", Toast.LENGTH_SHORT).show()
                return@doAfterTextChanged
            }
            previous = now
            quit.isEnabled = now.trim() == exitText
        }
    }
}
