# FocusLock

Study lock for Android. Set a goal and a time; until the timer ends only the timer, phone calls,
SMS and your allowed apps (WhatsApp + Telegram by default) work. Everything else is bounced back to the timer.
When the timer runs out the session is saved automatically and everything unlocks.

## Build the APK

**Option A - Android Studio:** File > Open > this folder, wait for Gradle sync, then Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

**Option B - no installs (GitHub):**
1. Push this project to a GitHub repository.
2. Open the repository's **Actions** tab and select **Build APK**.
3. Run the workflow with **Run workflow** (or push a commit to trigger it).
4. Open the successful run and download the **FocusLock-apk** artifact.
5. Extract the ZIP and install `app-debug.apk` on your phone.

## First-run setup on the phone
1. Install the APK (allow "install unknown apps").
2. If Accessibility is greyed out (Android 13+): Settings > Apps > FocusLock > three dots > Allow restricted settings.
3. Open FocusLock, tap Enable next to Accessibility, turn FocusLock on.
4. Allow "Display over other apps" (needed so the timer can reliably come back to the front) and Unrestricted battery.
5. Pick allowed apps, set goal + minutes, Start.

## Notes
- The timer uses the phone's monotonic clock, so changing the date/time does not shorten a session
  (after a reboot it falls back to the normal clock).
- Permission pop-ups, the photo/file picker and the camera are allowed during a session so allowed
  apps keep working. Package names differ between phone brands; if some system screen still gets
  blocked, add its package to `BlockerService.allowed()`.
- Review the accessibility permissions before enabling the app. It has not been verified on a
  physical phone in this bundle.
