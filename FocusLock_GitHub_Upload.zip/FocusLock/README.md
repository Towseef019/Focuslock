# FocusLock

Study lock for Android. Set a goal and a time; until the timer ends only the timer, phone calls,
SMS and your allowed apps (WhatsApp + Telegram by default) work. Everything else is bounced back to the timer.

## Build the APK

**Option A - Android Studio:** File > Open > this folder, wait for Gradle sync, then Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

**Option B - no installs (GitHub):** push this folder to a new GitHub repo, open the Actions tab,
run "Build APK", download the `FocusLock-apk` artifact.

## First-run setup on the phone
1. Install the APK (allow "install unknown apps").
2. If Accessibility is greyed out (Android 13+): Settings > Apps > FocusLock > three dots > Allow restricted settings.
3. Open FocusLock, tap Enable next to Accessibility, turn FocusLock on.
4. Allow "Display over other apps" and Unrestricted battery.
5. Pick allowed apps, set goal + minutes, Start.

## Download the APK from GitHub

1. Push this project to a GitHub repository.
2. Open the repository's **Actions** tab and select **Build APK**.
3. Run the workflow with **Run workflow** (or push a commit to trigger it).
4. Open the successful workflow run and download the **FocusLock-apk** artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

Review the accessibility permissions before enabling the app. It has not been verified on a physical phone in this bundle.
